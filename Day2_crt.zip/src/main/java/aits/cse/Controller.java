package aits.cse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class controller {

    @GetMapping("/")
    public String home() {
        return "home"; // This will serve home.html
    }
    @GetMapping("/login")
    public String login() {
        return "login"; // This will serve home.html
    }

    @GetMapping("/name")
    public String hello() {
        return "name"; // This will serve name.html
    }

    @GetMapping("/job")
    public String profession() {
        return "job"; // This will serve job.html
    }

    @GetMapping("/hobby")
    public String hobby() {
        return "hobby"; // This will serve hobby.html
    }
}

